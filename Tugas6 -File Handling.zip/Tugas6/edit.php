<?php

$file = "data.txt";
$data = file_get_contents($file);

$editbaris = $_GET['baris'];
$baris = explode("[R]", $data);
$kolom = explode("|F|", $baris[$editbaris]);
?>

<!DOCTYPE html>
<html>
    <body>
        <form action="save.php" method="POST">
            Nama: <input type="text" id="name"
                    name="nama"
                    value="<?php echo $kolom[0] ?>"><br>
            Email: <input type="email" id="email"
                    name="email"
                    value="<?php echo $kolom[1] ?>"><br>
            Phone: <input type="tel" id="phone"
                    name="phone"
                    value="<?php echo $kolom[2] ?>"><br>
            Prodi: <input type="text" id="prodi"
                    name="prodi"
                    value="<?php echo $kolom[3] ?>"><br>
            <input type="hidden" name="baris" value="<?php echo $editbaris ?>">
            <input type="submit" value="Save!">
        </form>
    </body>
</html>