<?php

$file = "data.txt";

$nama = $_POST['nama'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$prodi = $_POST['prodi'];

$edit = $nama  . "|F|" . 
        $email . "|F|" .
        $phone . "|F|" .
        $prodi . "[R]";

$data = file_get_contents($file);

$editbaris = $_POST['baris'];

$baris = explode("[R]", $data);
$databaru = "";

for($i = 0; $i<count($baris)-1; $i++) {
    if($i == $editbaris) {
    	$databaru .= $edit;
    	continue;
    }
    $databaru .= $baris[$i] . "[R]";
}

file_put_contents($file, $databaru);

header('location:baca.php');