<?php

$file = "data.txt";

$nama = $_POST['nama'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$prodi = $_POST['prodi'];

$data = $nama  . "|F|" . 
        $email . "|F|" .
        $phone . "|F|" .
        $prodi . "[R]";

$handle = fopen($file, "a+");
fwrite($handle, $data);
fclose($handle);

echo "Data sudah disimpan!";