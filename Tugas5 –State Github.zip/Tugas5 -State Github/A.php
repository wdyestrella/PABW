<!DOCTYPE html>
<head>
    <title>Tugas B</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <div class="form">
        <form action="B.php" method="POST">
            <input name="nama" type="text" placeholder="Masukkan Nama Anda...">
        </form>
    </div>
</body>
</html>