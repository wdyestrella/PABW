<?php
$_POST['nama'];
$_SESSION['nama'] = $_POST['nama'];
$nama = $_SESSION['nama'];
$browser_id = $_SERVER["HTTP_USER_AGENT"];
$time = date("H");
if ($time < "11") {
    $ucapan = "Pagi";
}elseif ($time < "15"){
    $ucapan = "Siang";
}elseif ($time < "18"){
    $ucapan = "Sore";
}elseif ($time >= "18" || $time < "03"){
    $ucapan = "Malam";
}
if(strpos($browser_id,"IE")){
	$browser = "Microsoft Internet Explorer";
}elseif (strpos($browser_id,"Firefox")){
	$browser = "Firefox";
}elseif (strpos($browser_id,"Chrome")){
	$browser = "Chrome";
}elseif (strpos($browser_id,"Safari")){
	$browser = "Safari";
}elseif (strpos($browser_id,"Edge")){
	$browser = "Microsoft Edge";
}else{
	$browser = "unknown";
}
?>

<!DOCTYPE html>
<head>
    <title>Tugas B</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <div class="form" align="center">
        <h2><?php echo "Selamat $ucapan, $nama !" ?></h2>
        Anda menggunakan web browser <?php echo $browser?>
        <br><br><br>
    </div>
</body>
</html>