<?php

include "connect.php";

$id = $_GET['id'];
$sql = mysqli_query($link, "SELECT * FROM phonebook WHERE id = '$id'");
$row = mysqli_fetch_array($sql);

?>

<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <form method="post" action="update.php">
            <input type="hidden" value="<?php echo $row['id'];?>" name="id">
            <table>
                <tr>
                    <td>Nama </td>
                    <td><input type="text" value="<?php echo $row['nama'];?>" name="nama"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" value="<?php echo $row['email'];?>" name="email"></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td><input type="tel" value="<?php echo $row['tel'];?>" name="phone"></td>
                </tr>
                    <tr><td>Prodi</td>
                    <td><input  type="text"  value="<?php echo $row['prodi'];?>" name="prodi"></td>
                </tr>
                <tr>
                    <td colspan="2"><button type="submit" value="simpan">SAVE</button></td>
                </tr>
            </table>
        </form>
    </body>
</html>