<?php

include 'connect.php';

$id 	= $_POST['id'];
$nama	= $_POST['nama'];
$email	= $_POST['email'];
$phone  = $_POST['phone'];
$prodi  = $_POST['prodi'];

$query = "UPDATE phonebook SET nama='$nama',email='$email',tel='$phone',prodi='$prodi' WHERE id='$id'";

mysqli_query($link, $query);

header("location:select.php");

?>