<?php

include "connect.php";
$nama	= $_POST['nama'];
$email	= $_POST['email'];
$tel	= $_POST['phone'];
$prodi	= $_POST['prodi'];

$sql = "INSERT INTO phonebook (nama, email, tel, prodi) " . "VALUES ('$nama','$email','$tel', '$prodi')";

/* eksekusi query SQL */
$res = mysqli_query($link, $sql);
if($res) echo "Data berhasil disimpan.";
else echo mysqli_error($link);

/* tutup koneksi MySQL */
mysqli_close($link);

?>